

<?php $__env->startSection('content'); ?>
    <input type="hidden" id="jawabancount" value="<?php echo e($lastJawaban); ?>">
    <input type="hidden" id="id_soal" value="<?php echo e($soal->id); ?>">
    <input type="hidden" id='url' value="<?php echo e(route('readingsection.store')); ?>">

    

    <!-- Main Program -->
    <main class="py-4">
        <section class="content">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-md-11">
                        <div class="card card-body bg-info">
                            <h6><i class="fas fa-info"></i> <b>Reading Section</b></h6>
                            This page has been enhanced for printing. Click the print button at the bottom of the invoice to
                            test.
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-md-9">
                        <div class="card card-info card-outline">
                            <div class="card-header">
                                <div class="row">
                                    <div class="col-md-1 px-1 bg-danger"><i class="fas fa-stopwatch"></i> Timer:</div>
                                    <div class="col-md-1 bg-success">00:00:00</div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row justify-content-center">
                                    <div class="col-md-12">
                                        <div class="list-group">
                                            <?php if(!empty($narasi)): ?>
                                                <div class="list-group-item">
                                                    <div class="row">
                                                        <h6><b>Direction</b></h6>
                                                        <div class="form-group row">
                                                            <p class="col-sm-12">
                                                                <?php echo e($narasi->narasi); ?>

                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            <div class="list-group-item">
                                                <div class="row">
                                                    <h6><b>Soal No. 1</b></h6>
                                                    <form class="form">
                                                        <div class="form-group row">
                                                            <p for="inputEmail3" class="col-sm-5"><?php echo e($soal->soal); ?></p>
                                                            <div class="col-sm-12">
                                                                <?php if($soal->jenis == 2): ?>
                                                                    <div class="form-group">
                                                                        <input type="text" class="form-control"
                                                                            id="essay" placeholder="Answer"
                                                                            <?php $__currentLoopData = $jawabanpesertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawabanpeserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($jawabanpeserta->soals_id == $soal->id): ?>
                                                                                <?php echo e('value=' . $jawabanpeserta->jawaban); ?>

                                                                            <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                                                    </div>
                                                                <?php else: ?>
                                                                    <div class="form-group row">
                                                                        <?php $__currentLoopData = $jawabans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawaban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($jawaban->soals_id == $soal->id): ?>
                                                                                <div class="col-md-4">
                                                                                    <div
                                                                                        class="custom-control custom-radio">
                                                                                        <input
                                                                                            <?php $__currentLoopData = $jawabanpesertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawabanpeserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                            <?php if($jawabanpeserta->jawabans_id == $jawaban->id): ?>
                                                                                             checked
                                                                                            <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                            class="custom-control-input"
                                                                                            type="radio"
                                                                                            id="jawaban<?php echo e($jawaban->id); ?>"
                                                                                            name="soal<?php echo e($soal->id); ?>"
                                                                                            value="<?php echo e($jawaban->id); ?>">
                                                                                        <label
                                                                                            for="jawaban<?php echo e($jawaban->id); ?>"
                                                                                            class="custom-control-label">
                                                                                            <?php echo e($jawaban->jawaban); ?></label>
                                                                                    </div>
                                                                                </div>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <a type="submit" class="btn btn-info float-left">Soal Sebelumnya</a>
                                <a type="submit" href="/fontend/finish.html" class="btn btn-info float-right">Soal
                                    Selanjutnya</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="card card-info card-outline">
                            <div class="card-header">
                                <div class="row">
                                    <div class="col">Nomor Soal</div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row justify-content-center">
                                    <?php $__currentLoopData = $soalsection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-3">
                                            <a href="<?php echo e(route('readingsection.show', $soals->id)); ?>"
                                                class="btn <?php if($soal->id == $soals->id): ?> btn-secondary <?php else: ?> btn-primary <?php endif; ?>"><?php echo e($loop->iteration); ?></a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <!-- End Main Program -->


    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
    <script>
        $(document).ready(function() {
            let countjawaban = $('#jawabancount').val();
            let url = $('#url').val();
            let id_soal = $('#id_soal').val();
            var jawaban = [];
            for (let index = 1; index <= countjawaban; index++) {
                jawaban[index] = $('#jawaban' + index.toString());
            }

            for (let index = 1; index <= countjawaban; index++) {
                jawaban[index].click(function(e) {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    var jawabanpeserta = jawaban[index].val();
                    $.ajax({
                        type: 'POST',
                        url: 'http://127.0.0.1:8000/english-test/storejawaban',
                        data: {
                            jawabans_id: jawabanpeserta,
                            soals_id: id_soal
                        },
                        dataType: 'json',
                        success: function(data) {}
                    });
                });
            }
            essay = $('#essay');


            essay.change(function() {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: 'POST',
                    url: 'http://127.0.0.1:8000/english-test/storejawaban',
                    data: {
                        jawaban: essay.val(),
                        soals_id: id_soal
                    },
                    dataType: 'json',
                    success: function(data) {}
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sima\Documents\GitHub\english-test\resources\views/peserta/reading.blade.php ENDPATH**/ ?>

 
<?php $__env->startSection('content'); ?>
    <div class="row mt-5">
        <div class="col-lg-12 margin-tb">
            <div class="float-start">
                <h2>JAWABAN PESERTA</h2>
            </div>
            
        </div>
    </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Soal</th>
            <th>Jawaban</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $jawabans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawaban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($jawaban->soal); ?></td>
            <td><?php echo e($jawaban->jawaban); ?></td>
            <td>
                <form action="<?php echo e(route('jawabanPesertas.update',$jawaban->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="is_checked" value="1"  > 
                    <input type="hidden" name="is_true" value="1"  > 
                    <button type="submit" class="btn btn-primary">Benar</button>
                </form>
                <form action="<?php echo e(route('jawabanPesertas.update',$jawaban->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="is_checked" value="1"  > 
                    <button type="submit" class="btn btn-danger">Salah</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div class="row text-center">
        <?php echo $jawabans->links(); ?>

    </div>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('jawabanPesertas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sima\Documents\GitHub\english-test\resources\views/jawabanPesertas/index.blade.php ENDPATH**/ ?>
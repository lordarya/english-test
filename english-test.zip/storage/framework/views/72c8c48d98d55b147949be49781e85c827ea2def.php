
<?php $__env->startSection('content'); ?>
    <!-- Main Program -->
    <main class="py-4">
        <input type="hidden" id="soalcount" value="<?php echo e($lastSoal); ?>">
        <input type="hidden" id="jawabancount" value="<?php echo e($lastJawaban); ?>">
        <section class="content">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-md-11">
                        <div class="card card-body bg-info">
                            <h6><b>I. Listening Section</b></h6>
                            This page has been enhanced for printing. Click the print button at the bottom of the invoice to
                            test.
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-md-11">
                        <div class="card card-info card-outline">
                            <div class="card-header">
                                <div class="row">
                                    <div class="col-md-1 px-2 bg-danger"><i class="fas fa-stopwatch"></i> Timer:</div>
                                    <div class="col-md-1 bg-success">00:00:00</div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row justify-content-center">
                                    <button id="myBtn" onclick="play()" type="button">Play Audio</button>
                                    <audio id="myAudio">
                                        <source src="/dist/img/High School in Jakarta.mp3" type="audio/mpeg">
                                    </audio>
                                </div>
                                <hr style="background-color: black; border-width: 2px;">
                                <div class="row mt-3">
                                    <div class="col-md-12">
                                        <div class="list-group">
                                            <?php $__currentLoopData = $soalsection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="list-group-item">
                                                    <div class="row">
                                                        <h6><b>Soal No. <?php echo e($loop->iteration); ?></b></h6>
                                                        <div class="form-group row">
                                                            <p class="col-sm-5">
                                                                <?php echo e($soal->soal); ?></p>
                                                            <div class="col-sm-12">
                                                                <?php if($soal->jenis == 2): ?>
                                                                    <div class="form-group">
                                                                        <input type="text" class="form-control"
                                                                            id="essay<?php echo e($soal->id); ?>"
                                                                            placeholder="Answer"
                                                                            <?php $__currentLoopData = $jawabanpesertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawabanpeserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($jawabanpeserta->soals_id == $soal->id): ?>
                                                                                <?php echo e('value=' . $jawabanpeserta->jawaban); ?>

                                                                            <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                                                    </div>
                                                                <?php else: ?>
                                                                    <div class="form-group row">
                                                                        <?php $__currentLoopData = $jawabans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawaban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($jawaban->soals_id == $soal->id): ?>
                                                                                <div class="col-md-4">
                                                                                    <div
                                                                                        class="custom-control custom-radio">
                                                                                        <input
                                                                                            <?php $__currentLoopData = $jawabanpesertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawabanpeserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                            <?php if($jawabanpeserta->jawabans_id == $jawaban->id): ?>
                                                                                             checked
                                                                                            <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                            class="custom-control-input"
                                                                                            type="radio"
                                                                                            id="jawaban<?php echo e($jawaban->id); ?>"
                                                                                            name="soal<?php echo e($soal->id); ?>"
                                                                                            value="<?php echo e($jawaban->id . '.' . $soal->id); ?>">
                                                                                        <label
                                                                                            for="jawaban<?php echo e($jawaban->id); ?>"
                                                                                            class="custom-control-label">
                                                                                            <?php echo e($jawaban->jawaban); ?></label>
                                                                                    </div>
                                                                                </div>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-info float-right" data-toggle="modal"
                                    data-target="#modal-sm">Submit
                                    Test</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>


    <!-- End Main Program -->


    <div class="modal fade" id="modal-sm">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><b>Confirmation Message</b></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Do you want to submit the answer?</p>
                </div>
                <div class="modal-footer justify-content-between">
                    <a class="btn btn-danger" data-dismiss="modal">No</a>
                    <form action="<?php echo e(route('listeningsection.update', 1)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <button class="btn btn-success" href="/fontend/readingobjective.html">Yes</button>
                    </form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->

    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
    <script>


var aud = document.getElementById("myAudio");
function play() { 
  aud.play(); 
  document.getElementById("myBtn").disabled = true;
} 
aud.onended = function() {
  alert("The audio has ended");
};




        $(document).ready(function() {
            let countjawaban = $('#jawabancount').val();
            let countsoal = $('#soalcount').val();
            var jawaban = [];
            var essay = [];
            for (let index = 1; index <= countjawaban; index++) {
                jawaban[index] = $('#jawaban' + index.toString());
            }

            for (let index = 1; index <= countjawaban; index++) {
                jawaban[index].click(function(e) {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    var jawabanpeserta = jawaban[index].val();
                    var test = jawabanpeserta.match(/(.+)\.(.+)/);
                    $.ajax({
                        type: 'POST',
                        url: 'http://127.0.0.1:8000/english-test/storejawaban',
                        data: {
                            jawabans_id: test[1],
                            soals_id: test[2]
                        },
                        dataType: 'json',
                        success: function(data) {}
                    });
                });
            }
            for (let index = 1; index <= countsoal; index++) {
                essay[index] = $('#essay' + index.toString());
            }

            for (let index = 1; index <= countsoal; index++) {
                essay[index].change(function() {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: 'POST',
                        url: 'http://127.0.0.1:8000/english-test/storejawaban',
                        data: {
                            jawaban: essay[index].val(),
                            soals_id: index
                        },
                        dataType: 'json',
                        success: function(data) {}
                    });
                });


            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sima\Documents\GitHub\english-test\resources\views/peserta/listening.blade.php ENDPATH**/ ?>
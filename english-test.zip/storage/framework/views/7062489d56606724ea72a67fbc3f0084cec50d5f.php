

<?php $__env->startSection('content'); ?>
    <div class="row mt-5">
        <div class="col-lg-12 margin-tb">
            <div class="float-start">
                <h2> PESERTA</h2>
            </div>

        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <a class="btn btn-danger" href="<?php echo e(route('logout')); ?>"
        onclick="event.preventDefault();
        document.getElementById('logout-form').submit();">
        <?php echo e(__('Logout')); ?>

    </a>

    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
        <?php echo csrf_field(); ?>
    </form>

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Level</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $pesertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawaban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($jawaban->user->name); ?></td>
                <td><?php echo e($jawaban->level); ?></td>
                <td>
                    <form action="<?php echo e(route('pesertas.destroy', $jawaban->id)); ?>" method="POST">
                        <a class="btn btn-info" href="<?php echo e(route('jawabanPesertas.show', $jawaban->user->id)); ?>">Show</a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div class="row text-center">
        <?php echo $pesertas->links(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sima\Documents\GitHub\english-test\resources\views/admin/pesertas/index.blade.php ENDPATH**/ ?>